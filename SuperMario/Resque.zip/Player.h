#pragma once
void InitializePlayer();
void PlayerMove();