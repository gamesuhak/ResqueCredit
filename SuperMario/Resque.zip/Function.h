#pragma once
int Random(int value);
int RandomRange(int start, int end);