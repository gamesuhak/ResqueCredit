#pragma once
typedef enum State { STATE_IDLE = 0, STATE_WALK, STATE_ATTACK, STATE_COUNT } State;
