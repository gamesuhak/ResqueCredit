#pragma once
typedef enum SceneType { SCENE_TITLE, SCENE_GAME, SCENE_EDIT, SCENE_COUNT } SceneType;